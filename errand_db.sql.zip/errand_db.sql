-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2018 at 04:56 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `errand_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `project_user_id` int(11) NOT NULL,
  `project_title` varchar(255) NOT NULL,
  `project_body` text NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `project_user_id`, `project_title`, `project_body`, `date_created`) VALUES
(1, 0, 'PHP', 'This task involves coding a script that echo names.', '2018-02-23 11:00:50'),
(3, 11, 'Bootstrap', 'Bootstrap is the best responsive thing.', '2018-02-23 12:29:04'),
(8, 11, 'c', 'c is a very easy language.......', '2018-02-23 19:21:54'),
(9, 19, 'codeigniter', 'it is very good and easy framework. i am very happy to learn it', '2018-03-08 11:34:03'),
(10, 19, 'IA', 'IA stands for informatic assistant', '2018-03-08 11:53:37');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `task_name` varchar(255) NOT NULL,
  `task_body` text NOT NULL,
  `due_date` date NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `project_id`, `task_name`, `task_body`, `due_date`, `date_created`, `status`) VALUES
(1, 3, 'PHP Courses', 'take the abc\'s php course', '2018-03-17', '2018-02-24 10:21:02', 1),
(3, 3, 'task for project id 8', 'task for project id 8', '2018-02-28', '2018-02-24 11:39:24', 0),
(7, 8, 'PHP Courses', 'javascript course is difficult. take my course to make your trouble easy.', '2018-03-16', '2018-02-25 13:21:08', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `photo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `first_name`, `last_name`, `email`, `register_date`, `photo`) VALUES
(2, 'khushboo', '12345', '', '', '', '2018-02-18 09:11:04', ''),
(3, 'geetika', '123456', '', '', '', '2018-02-18 09:11:04', ''),
(4, 'vivekmodi', '1234567890', 'vivek', 'modi', 'modiv2301@gmail.com', '2018-02-20 12:02:21', ''),
(7, 'seemamodi', 'pmskgv', 'seema', 'modi', 'seema@gmail.com', '2018-02-20 12:07:31', ''),
(8, 'modi200', '$2y$12$8YWLEFUdUvY8iCswhYX09exOHj4bpBqKusjGN7.zdgzbOCmi1.4VS', 'manohar', 'modi', 'manohar.modi@gmail.com', '2018-02-20 12:22:56', ''),
(11, 'neeleshjain', '$2y$12$TfaNi14Jk6i76kPKFhpsluZfThPDf68cIWyI/01XVIXKfIH7rUGhS', 'neelesh', 'jain', 'neeleshjain85@gmail.com', '2018-02-20 12:31:17', ''),
(12, 'rammodi', '$2y$12$iK8rd.sxsgygyx7W7wUOm.203KZscbRv8tZahWbK7T4CMBSjxZPFW', 'ram', 'modi', 'ram@gmail.com', '2018-02-20 12:45:50', ''),
(13, 'vmodi', '$2y$12$3NnbX07sngNxWF.PYC88.OZaEkXv4Wt/q7uCcZEDG07tZqGi848na', 'vivek', 'modi', 'abc@gmail.com', '2018-03-08 08:02:51', ''),
(14, 'vmodi', '$2y$12$hGN4Ihjzz4m3pMKxkc3lYO2lRFAQUn15fC.28gvtjbW/cyD/u5wau', 'vivek', 'modi', 'abc@gmail.com', '2018-03-08 08:04:49', ''),
(15, 'kmodi', '$2y$12$PyoxoMLUFdXiwrEX6U6eBepWE21wlETDFhejgasf.KX2tw.Y74rxW', 'khushboo', 'modi', 'khushboomodi1987@gmail.com', '2018-03-08 08:17:16', '1520497036kmodi.jpg'),
(16, 'neeleshj', '$2y$12$x82D9LfY.AWXEE0WT0MLcOkDIeuMm2Lv.G60Y.AWngM/CfLZLG9ea', 'vivek', 'modi', 'modiv2301@gmail.com', '2018-03-08 09:00:09', '1520499609neeleshj.jpg'),
(17, 'khushboom', '$2y$12$CSYl7o6qHcLDPkMMf2bmdOAAmnGu/9BVLyGSYsBJt0ShofiaXwR.K', 'vivek', 'modi', 'khushboomodi1987@gmail.com', '2018-03-08 09:00:49', '1520499649khushboom.jpg'),
(18, 'aaaaaa', '$2y$12$qZn8PnYUPvZ6GlviIj.D0.7sxVUMBt2f4ibiynGZlt82DrQnLZ0XW', 'aaa', 'aaa', 'aaaa@gmail.com', '2018-03-08 09:02:52', '1520499772aaaaaa.jpg'),
(19, 'neelkhush', '$2y$12$PAwiqRNjRmuXZxqZcS0N7.83u0MvLdl7Zw3Gz4LF5HtWIg3dBjMre', 'neelesh', 'jain', 'neeleshjain85@gmail.com', '2018-03-08 10:00:49', '1520503248neelkhush.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
