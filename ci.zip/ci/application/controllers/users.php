<?php 
class Users extends CI_Controller
{
	// public function show($user_id)
	// {
	// 	//$this->load->model("user_model");
	// 	$data['result'] = $this->user_model->get_users($user_id, 'khushboo');
	

	// 	$this->load->view('user_view',$data);
	// 	/*foreach ($result as $object)
	// 	{
	// 		echo $object->id . "<br>";
	// 	}*/
	// }

	// public function insert()
	// {
	// 	$username="vivek";
	// 	$password="1234";
	// 	$this->user_model->create_user([
	// 		'username' => $username,
	// 		'password' => $password
	// 	]);
	// }

	// public function update()
	// {
	// 	$id=3;
	// 	$username="geetika";
	// 	$password="123456";
	// 	$this->user_model->update_user([
	// 		'username' => $username,
	// 		'password' => $password
	// 	], $id);
	// }

	// public function delete()
	// {
	// 	$id=1;
	// 	$this->user_model->delete_user($id);
	// }

	public function register()
	{
		$this->form_validation->set_rules('first_name','First Name', 'trim|required|min_length[3]');
		$this->form_validation->set_rules('last_name','Last Name', 'trim|required|min_length[3]');
		if (empty($_FILES['photo']['name']))
		{
    		$this->form_validation->set_rules('photo', 'User Photo', 'required');
		}
		$this->form_validation->set_rules('email', 'Email', 'trim|required|min_length[3]|valid_email');
		$this->form_validation->set_rules('username', 'User Name', 'trim|required|min_length[3]');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[3]');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|min_length[3]|matches[password]');
		if($this->form_validation->run() == FALSE)
		{
			$data = array('main_view' => 'users/register_view');
        	$this->load->view('layout/main', $data);
        }
        else
        {
        	$photo_path = base_url("uploads/users/");
        	$config = [
				'upload_path' => $photo_path,
				'allowed_types' => 'jpg|jpeg',
				'file_name' => time().$this->input->post('username'),
				'max_size' => '50',
				'min_width' => '80',
				'min_height' => '200',
				'max_width' => '200',
				'max_height' => '560'
			];
			$this->upload->initialize($config);
			if($this->upload->do_upload('photo') == FALSE)
			{

				$data = array('main_view' => 'users/register_view','upload_error' => $this->upload->display_errors());
        		$this->load->view('layout/main', $data);
			}
			else
			{
	        	if($this->user_model->create_user())
	        	{
	        		$this->session->set_flashdata('user_registered', 'You are successfully registered');
	        		// $data = array('main_view' => 'home_view' );
	        		// $this->load->view('layout/main', $data);
	        		redirect('home/index');
	        	}
	        	else
	        	{

	        	}
	        }
        }
	}

	public function login()
	{

		$this->form_validation->set_rules('username', 'User Name', 'trim|required|min_length[3]');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[3]');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|min_length[3]|matches[password]');

		if($this->form_validation->run() == FALSE)
		{
			$data = array(
				'error' => validation_errors()
				 );
			$this->session->set_flashdata($data);
			// $data = array('main_view' => 'home_view');
   //       	$this->load->view('layout/main', $data);
			redirect('home/index');
		}
		else
		{
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$user_detail = $this->user_model->login_user($username,$password);

			if($user_detail->id)
			{
				$user_data = array(
					'user_id' => $user_detail->id,
					'username' => $username,
					'photo' => $user_detail->photo,
					'logged_in' => true
					 );
				$this->session->set_userdata($user_data);
				$this->session->set_flashdata('login_success','You are successfully logged in');
				// $data = array('main_view' => 'admin_view');
    //      		$this->load->view('layout/main', $data);
				redirect('home/index');
			}
			else
			{
				$this->session->set_flashdata('login_failed','You are failed to login');
				// $data = array('main_view' => 'home_view');
    			//$this->load->view('layout/main', $data);
    			redirect('home/index');
			}
		}
		
		//echo $this->input->post('username');

	}
	public function logout()
	{
		$this->session->sess_destroy();
		redirect('home/index');
	}

	public function valid_username()
	{
		if($this->user_model->username_exist($_POST['username']))
		{
			echo "1";
		}
	}
}

?>