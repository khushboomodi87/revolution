<?php 
// stream_context_get_default([
// 	'ssl' => [
// 		'verify_peer' => false,
// 		'verify_peer_name' => false]
// ]);
class Email extends CI_Controller
{

	
	public function index()
	{
		$config = Array( 
	  'protocol' => 'smtp', 
	  'smtp_host' => 'ssl://smtp.googlemail.com', 
	  'smtp_port' => 587, 
	  'smtp_user' => 'khushboomodi87@gmail.com', 
	  'smtp_pass' => 'password' ); 

  		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");

		$this->email->from('khushboomodi87@gmail.com', 'Khushboo');
		$this->email->to('khushboomodi87@gmail.com');
		$this->email->subject('This is an email test');
		$this->email->message('It is working. Great!');

		if($this->email->send())
		{
			echo "your email has been sent";
		}
		else
		{
			show_error($this->email->print_debugger());
		}

	}
}

?>