<?php if($this->session->userdata('logged_in')): ?>
	<h2>Logout</h2>

	<?php echo form_open('users/logout'); ?>
	<?php if ($this->session->userdata('username')): ?>
		<?php echo "you are logged in as " . $this->session->userdata('username'); ?>
	<?php endif; ?>
	<?php 
		$data = array(
			'src' => base_url()."uploads/users/".$this->session->userdata('photo'),
			'alt' => 'No Image',
			'class' => 'post_images',
			'width' => '100',
			'height' => '100',
			'rel' => 'lightbox'
			 );
	 ?>	
	 <?php echo img($data); ?>
	<?php 
		$data = array(
			'class' => 'btn btn-primary',
			'name' => 'submit',
			'value' => 'Logout'
		);
	?>
	<?php echo form_submit($data); ?>
	<?php echo form_close(); ?>

<?php else: ?>
	
	<h1>Login Form</h1>

	<?php $attributes = array('id' => 'login_form' , 'class' => 'form_horizontal' ); ?>


	<?php if($this->session->flashdata('error')): ?>
		<?php echo $this->session->flashdata('error'); ?>
	<?php endif; ?>
	
	<?php echo form_open('users/login', $attributes); ?>
	
	<div class="form-group">
	
		<?php echo form_label('User Name'); ?>
		<?php 
			$data = array(
				'class' => 'form-control',
				'placeholder' => 'Enter User Name',
				'name' => 'username'
			 	);
	 	?>
	 	<?php echo form_input($data); ?>
	
	</div>
	
	
	<div class="form-group">
		
		<?php echo form_label('Password'); ?>
		<?php 
			$data = array(
				'class' => 'form-control',
				'placeholder' => 'Enter Password',
				'name' => 'password'
			 	);
	 	?>
	 	<?php echo form_password($data); ?>
	
	</div>
	
	<div class="form-group">
		
		<?php echo form_label('Confirm Password'); ?>
		<?php 
			$data = array(
				'class' => 'form-control',
				'placeholder' => 'Confirm Password',
				'name' => 'confirm_password'
			 	);
	 	?>
		<?php echo form_password($data); ?>
	</div>
	
	<div class="form-group">
		
		<?php 
			$data = array(
				'class' => 'btn btn-primary',
				'name' => 'submit',
				'value' => 'Login'
			);
	 	?>
		 <?php echo form_submit($data); ?>

	</div>

	<?php echo form_close(); ?>
<?php endif; ?>