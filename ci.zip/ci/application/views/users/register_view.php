<h1>Registration Form</h1>

<?php $attribut = array('id' =>'registration_form' , 'class'  => 'form_horizontal'); ?>

<!-- <?php// echo validation_errors("<p class='bg-danger'>");?> -->

<?php echo form_open_multipart('users/register', $attribut); ?>

<div class="form-group">
	
	<?php echo form_label('First Name'); ?>
	<?php
		$data = array(
			'class' => 'form-control',
			'placeholder' => 'Enter First Name',
			'name' => 'first_name',
			'value' => set_value('first_name')
		); 
	 ?>
	 <?php echo form_input($data); ?>
	 <?php echo form_error('first_name',"<p class='bg-danger'>"); ?>
</div>

<div class="form-group">
	 <?php echo form_label('Last Name'); ?>
	 <?php 
	 	$data = array(
	 		'class' => 'form-control',
	 		'placeholder' => 'Enter Last Name',
	 		'name' => 'last_name',
	 		'value' => set_value('last_name')
	 	);
	  ?>
	  <?php echo form_input($data); ?>
	  <?php echo form_error('last_name',"<p class='bg-danger'>"); ?>
</div>

<div class="form-group">
	<?php echo form_label('Photo'); ?>
	<?php 
		$data = array(
			'class' => 'form-control',
			'name' => 'photo'
		 );
	 ?>
	 <?php echo form_upload($data); ?>
	 <?php echo form_error('photo',"<p class='bg-danger'>"); ?>
	 <?php if(isset($upload_error)): ?>
	 	<?php echo $upload_error; ?>
	 <?php endif; ?>

</div>

<div class="form-group">
	<?php echo form_label('Email'); ?>
	<?php 
		$data = array(
			'class' =>'form-control',
			'placeholder' => 'Enter Email',
			'name' => 'email',
			'value' => set_value('email')
		);
	 ?>
	 <?php echo form_input($data); ?>
	 <?php echo form_error('email',"<p class='bg-danger'>"); ?>

</div>

<div class="form-group">
	<?php echo form_label('User Name'); ?>
	<?php 
		$data = array(
			'class' => 'form-control',
			'placeholder' => 'Enter User Name',
			'name' => 'username',
			'value' => set_value('username'),
			'id' => 'username'
		);
	 ?>	
	 <?php echo form_input($data); ?>
	 <?php echo form_error('username',"<p class='bg-danger'>"); ?>

</div>

<div class="form-group">
	<?php echo form_label('Password'); ?>
	<?php 
		$data = array(
			'class' => 'form-control',
			'placeholder' => 'Enter Password',
			'name' => 'password'
		);
	 ?>
	 <?php echo form_password($data); ?>
	 <?php echo form_error('password',"<p class='bg-danger'>"); ?>

</div>

<div class="form-group">
	<?php echo form_label('Confirm Password'); ?>
	<?php 
		$data = array(
			'class' => 'form-control',
			'placeholder' => 'Confirm Password',
			'name' => 'confirm_password'
		);
	 ?>
	 <?php echo form_password($data); ?>
	 <?php echo form_error('confirm_password',"<p class='bg-danger'>"); ?>

</div>

<div class="form-group">
	<?php 
		$data = array(
			'class' => 'btn btn-primary',
			'value' => 'Register',
			'name' => 'submit' 
		);
	 ?>
	 <?php echo form_submit($data); ?>
</div>

<?php echo form_close(); ?>