<h1>Update Project</h1>

<?php $attribute = array('id' => 'update_form', 'class' => 'form_horizontal'); ?>
<?php echo form_open('projects/edit/'. $project_data->id .'',$attribute); ?>

<div class="form-group">
	<?php echo form_label('Project Name'); ?>
	<?php 
		$data = array(
			'class' => 'form-control',
			'name' => 'project_title',
			'value' => $project_data->project_title
		);
	?>
	<?php echo form_input($data); ?>
	<?php echo form_error('project_title',"<p class='bg-danger'>"); ?>
</div>
<div class="form-group">
	<?php echo form_label('Project Description'); ?>
	<?php
		$data = array(
			'class' => 'form-control',
			'name' => 'project_body',
			'value' => $project_data->project_body
		); 
	?>
	<?php echo form_textarea($data); ?>
	<?php echo form_error('project_body',"<p class='bg-danger'>"); ?>
</div>
<div class="form-group">
	<?php
		$data = array(
			'class' => 'btn btn-primary',
			'name' => 'submit',
			'value' => 'Update'
		); 
	 ?>
	 <?php echo form_submit($data); ?>
</div>

<?php echo form_close(); ?>