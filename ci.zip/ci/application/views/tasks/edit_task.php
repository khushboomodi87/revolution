<h1>Edit Task</h1>
<?php $attribute = array('id' => 'edit_task', 'class' => 'form-horizontal' ); ?>
<?php echo form_open('tasks/edit/'. $this->uri->segment(3).'',$attribute); ?>

<div class="form-group">
	<?php echo form_label('Task Name'); ?>
	<?php 
		$data = array(
			'class' => 'form-control',
			'name' => 'task_name',
			'value' => $task_data->task_name
		);
	 ?>
	 <?php echo form_input($data); ?>
	 <?php echo form_error('task_name',"<p class= 'bg-danger'>"); ?>
</div>

<div class="form-group">
	<?php echo form_label('Task Description'); ?>
	<?php 
		$data = array(
			'class' => 'form-control',
			'name' => 'task_body',
			'value' => $task_data->task_body
		 );
	 ?>
	 <?php echo form_textarea($data); ?>
	 <?php echo form_error('task_body', "<p class='bg-danger'>"); ?>
</div>

<div class="form-group">
	<?php 
		$data = array(
			'class' => 'form-control',
			'name' => 'due_date',
			'type' => 'date',
			'value' => $task_data->due_date
		 );
	 ?>
	 <?php echo form_input($data); ?>
</div>

<div class="form-group">
	<?php 
		$data = array(
			'class' => 'btn btn-primary',
			'name' => 'submit',
			'value' => 'Update'
		 );
	 ?>
	 <?php echo form_submit($data); ?>
</div>

<?php echo form_close(); ?>