<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

$config['protocol'] = 'smtp';
$config['smtp_host'] = 'ssl://smtp:googlemail.com';
$config['smtp_port'] = 587;
$config['smtp_user'] = 'khushboomodi87@gmail.com';
$config['smtp_pass'] = 'khush2234376';
?>