$(document).ready(function()
{
	$("#username").blur(function()
	{

		var username = $('#username').val();
		$.post('valid_username',{'username':username},
			function(result)
			{
				
				$('#bad_username').replaceWith('');
				if(result)
				{
					$('#username').after('<div id="bad_username" class="be-danger"> <p id="bad_username"> User name already exist</p></div>');
				}
			});
	 });
});